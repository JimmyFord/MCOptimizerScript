package me.opd.worldoptimizer;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class MobSpawnListener implements Listener {

    private final JavaPlugin plugin;

    public MobSpawnListener(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMobSpawn(CreatureSpawnEvent event) {
        if (!plugin.getConfig().getBoolean("mob-spawn-control.enabled")) return;

        int maxDistance = plugin.getConfig().getInt("mob-spawn-control.max-distance-from-player");

        boolean nearPlayer = event.getLocation().getWorld().getPlayers().stream()
                .anyMatch(player ->
                        player.getLocation().distanceSquared(event.getLocation())
                                <= maxDistance * maxDistance
                );

        if (!nearPlayer) {
            event.setCancelled(true);
        }
    }
}

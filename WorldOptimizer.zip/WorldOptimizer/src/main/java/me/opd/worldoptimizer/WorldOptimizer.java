package me.opd.worldoptimizer;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class WorldOptimizer extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Item cleanup task
        long interval = getConfig().getLong("item-cleanup.check-interval-ticks");
        Bukkit.getScheduler().runTaskTimer(
                this,
                new ItemCleanupTask(this),
                interval,
                interval
        );

        // Mob spawn listener
        Bukkit.getPluginManager().registerEvents(
                new MobSpawnListener(this),
                this
        );

        getLogger().info("WorldOptimizer enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("WorldOptimizer disabled.");
    }
}
